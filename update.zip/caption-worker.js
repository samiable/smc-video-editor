// Offline speech-to-text for auto captions. Runs in the background so the app never freezes.
import { pipeline, env } from './transformers.min.js';
env.allowRemoteModels = false;
env.allowLocalModels = true;
env.localModelPath = './models/';
env.backends.onnx.wasm.wasmPaths = './wasm/';
env.backends.onnx.wasm.numThreads = 1;
let asr = null;
self.onmessage = async (e) => {
  if (e.data.cmd !== 'run') return;
  try {
    if (!asr) {
      asr = await pipeline('automatic-speech-recognition', 'whisper-base', {
        quantized: true,
        progress_callback: (p) => self.postMessage({ type: 'load', p })
      });
    }
    self.postMessage({ type: 'status', text: 'Listening… this can take a few minutes on a tablet.' });
    const out = await asr(e.data.pcm, {
      language: e.data.lang || null,
      task: 'transcribe',
      return_timestamps: true,
      chunk_length_s: 30,
      stride_length_s: 5
    });
    self.postMessage({ type: 'done', out });
  } catch (err) {
    self.postMessage({ type: 'error', msg: String((err && err.message) || err) });
  }
};
